from http.server import HTTPServer, CGIHTTPRequestHandler
from flask import Flask, url_for, request, render_template
import json
import sys


app = Flask(__name__)

@app.route('/')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

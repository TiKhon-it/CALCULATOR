from http.server import HTTPServer, CGIHTTPRequestHandler
from flask import Flask, url_for, request


app = Flask(__name__)

@app.route('/')
def I():
    return 'Миссия Колонизация Марса'

@app.route('/index')
def index():
    return "И на Марсе будут яблони цвести!"

@app.route('/promotion')
def promotion():
    countdown_list = ["Человечество вырастает из детства.",
                      "Человечеству мала одна планета.",
                      "Мы сделаем обитаемыми безжизненные пока планеты.",
                      "И начнем с Марса!",
                      "Присоединяйся!"]
    return '</br>'.join(countdown_list)

@app.route('/image_mars')
def image_mars():
    return f"""<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="{url_for('static', filename='img/mars1.png')}" alt="здесь должна была быть картинка марса">
                    <h3>Вот она какая, красная планета<h3>
                  </body>
                </html>"""


@app.route('/promotion_image')
def promotion_image():
    return f'''<!doctype html>
                    <html lang="en">
                      <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                        <link rel="stylesheet" 
                        href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
                        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
                        crossorigin="anonymous">
                        <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                        <title>Колонизация</title>
                      </head>
                      <body>
                        <h1>Жди нас, Марс!</h1>
                        <img src="{url_for('static', filename='img/mars1.jpg')}" alt="здесь должна была быть картинка марса">
                        <div class="alert alert-dark" role="alert"> Человечество вырастает из детства.</div>
                        <div class="alert alert-success" role="alert">Человечеству мала одна планета.</div>
                        <div class="alert alert-dark" role="alert">Мы сделаем обитаемыми безжизненные пока планеты.</div>
                        <div class="alert alert-warning" role="alert">И начнем с Марса!</div>
                        <div class="alert alert-danger" role="alert">Присоединяйся!</div>
                      </body>
                    </html>'''

@app.route('/choice/<planet_name>')
def choice(planet_name):
    return f'''<!doctype html>
                    <html lang="en">
                      <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                        <link rel="stylesheet" 
                        href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
                        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
                        crossorigin="anonymous">
                        <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                        <title>Вырианты выбора</title>
                      </head>
                      <body>
                        <h1>Мое предложени: {planet_name}</h1>
                        <div class="alert alert-success" role="alert"> На ней много необходимых ресурсов;</div>
                        <div class="alert alert-dark" role="alert">На ней есть вода и атмосфера;</div>
                        <div class="alert alert-warning" role="alert">На ней есть не большое магнитное поле;</div>
                        <div class="alert alert-danger" role="alert">Наконец, она просто красива!</div>
                      </body>
                    </html>'''

@app.route('/astronaut_selection', methods=['POST', 'GET'])
def astronaut_selection():
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Отбор астронавтов</title>
                          </head>
                          <body>
                            <h1 align="center">Анкета претендента</h1>
                            <h2 align="center">на участие в мисси</h2>
                            <div>
                                <form class="login_form" method="post">
                                    <input type="fam" class="form-control" id="fam" placeholder="Введите фамилию" name="fam">
                                    <input type="nam" class="form-control" id="nam" placeholder="Введите имя" name="nam">
                                    <label for="about"></label>
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите свою почту" name="email">
                                    <div class="form-group">
                                        <label for="about">Какое у вас образование?</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>Начальное</option>
                                          <option>Основное</option>
                                          <option>Среднее</option>
                                          <option>Высшее</option>
                                        </select>
                                     </div>
                                    <label for="about"></label>
                                    <br><label for="about">Какие у Вас есть професси?</label>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept1">
                                        <label class="form-check-label" for="acceptRules">инженер-исследователь</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept2">
                                        <label class="form-check-label" for="acceptRules">инженер по терраформированию</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept3">
                                        <label class="form-check-label" for="acceptRules">астрогеолог</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept4">
                                        <label class="form-check-label" for="acceptRules">специалист по радиационной защите</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept5">
                                        <label class="form-check-label" for="acceptRules">оператор марсохода</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept6">
                                        <label class="form-check-label" for="acceptRules">штурман</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept7">
                                        <label class="form-check-label" for="acceptRules">пилот</label>
                                        <br><input type="checkbox" class="form-check-input" id="acceptRules" name="accept8">
                                        <label class="form-check-label" for="acceptRules">другое</label>
                                    </div>
                                    <label for="about"></label>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                          <label class="form-check-label" for="male">
                                            Мужской
                                          </label>
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                          <label class="form-check-label" for="female">
                                            Женский
                                          </label>
                                        </div>
                                    </div>
                                    <label for="about"></label>
                                    <div class="form-group">
                                        <label for="about">Почему Вы хотите принять участие в мисси?</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                    </div>
                                    <label for="about"></label>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе</label>
                                    </div>
                                    <label for="about"></label>
                                    <br><button type="submit" class="btn btn-primary">Отправить</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        print(request.form['email'])
        print(request.form['password'])
        print(request.form['class'])
        print(request.form['file'])
        print(request.form['about'])
        print(request.form['accept'])
        print(request.form['sex'])
        return "Форма отправлена"

@app.route('/results/<nickname>/<int:level>/<float:rating>')
def results(nickname, level, rating):
    return f'''<!doctype html>
                    <html lang="en">
                      <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                        <link rel="stylesheet" 
                        href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
                        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
                        crossorigin="anonymous">
                        <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                        <title>Результаты</title>
                      </head>
                      <body>
                        <h1>Результаты отбора</h1>
                        <h2>Претендента на участие в мисси {nickname}:</h2>
                        <div class="alert alert-success" role="alert">Поздравляем! Ващ рейтинг после {int(level)} этапа отбора</div>
                        <div class="alert alert-light" role="alert">составляет {float(rating)}!</div>
                        <div class="alert alert-warning" role="alert">Желаем удачи!</div>
                      </body>
                    </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

    





